# C++ Web-Socket Multiplayer Tic-Tac-Toe (B.Tech OOP Systems Project)

A production-grade, pedagogically rigorous C++ web backend utilizing the lightweight Crow C++ framework with real-time WebSockets, paired with a modern responsive web client, recursive Minimax single-player bot mode, and an interactive Academic Inspector for the 4 OOP Pillars & DSA/DAA algorithms.

### User Review & Critical Decisions

> [!IMPORTANT]
> **Single Player Bot Mode (Minimax Algorithm)**:
> In addition to human-vs-human online multiplayer, the architecture includes an autonomous **`AIPlayer`** that inherits polymorphically from the abstract base class `Player`. Rather than playing pseudo-random moves, it executes the **recursive Minimax decision tree algorithm** with heuristic depth penalties ($+10 - \text{depth}$ for AI win, $\text{depth} - 10$ for loss, $0$ for draw). This provides a rigorous demonstration of **Data Structures and Algorithms (DSA)** and **Design and Analysis of Algorithms (DAA)** zero-sum game theory.

- **Web Server Framework**: Crow C++ (C++17, Asio-driven, single-header or modular with minimal dependencies) exposing HTTP REST endpoints for Auth and `/ws` for bi-directional game events.
- **Data Persistence**: File-based `users.txt` using `<fstream>` with deterministic **Salted DJB2 algorithm** (Dan Bernstein's algorithm: $hash = ((hash \ll 5) + hash) + c$, initialized with $5381$, combined with per-user cryptographic salt string).
- **Single-Player Mode**: Instant matchmaking against `Minimax AI (Bot)` with real-time state broadcasts over WebSockets.

---

### 1. Overview & Core Concept

- **What It Does**: Allows two authenticated players to log in via a web interface, enter a multiplayer lobby, pair up in real-time rooms, or launch an instant Single Player match against a server-side Minimax AI bot. Moves are sent via WebSockets, processed by C++ OOP classes (`Board`, `GameSession`, `WebSocketPlayer`, `AIPlayer`), validated, and broadcast back to clients.
- **Target Audience / Persona**: 2nd-year B.Tech Computer Science & Engineering students, academic evaluators, and system programming professors who require rigorous OOP and DSA proofs alongside modern networking capabilities.

---

### 2. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        Web Client (Browser)                            │
│   ┌────────────────────┐   ┌──────────────────┐   ┌────────────────┐   │
│   │ Auth View (Log/Reg)│   │ Lobby (PvP & Bot)│   │ 3x3 Game Board │   │
│   └─────────┬──────────┘   └────────┬─────────┘   └────────┬───────┘   │
└─────────────┼───────────────────────┼──────────────────────┼───────────┘
              │ HTTP POST /api/auth   │ WebSocket /ws        │
              ▼                       ▼                      ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        C++ Web Backend (Crow)                          │
│                                                                        │
│   ┌────────────────────────────────────────────────────────────────┐   │
│   │             ServerNetworkManager (Abstraction)                 │   │
│   │    - Crow App HTTP & WebSocket Endpoints                       │   │
│   │    - Connection Lifecycle & Bot Match Dispatching              │   │
│   └───────────────┬─────────────────────────────┬──────────────────┘   │
│                   │                             │                      │
│                   ▼                             ▼                      │
│   ┌──────────────────────────────┐   ┌─────────────────────────────┐   │
│   │  AuthManager (Encapsulation) │   │ GameSession (Orchestration) │   │
│   │  - Read/Write users.txt      │   │ - Player 1 (Player*)        │   │
│   │  - Deterministic Salted DJB2 │   │ - Player 2 (Player*)        │   │
│   └───────────────┬──────────────┘   │ - Polymorphic Turn Loop     │   │
│                   │                  └──────────────┬──────────────┘   │
│                   ▼                                 │                  │
│     [ users.txt: user:salt:hash ]                   ▼                  │
│                                      ┌─────────────────────────────┐   │
│                                      │     Board (Encapsulation)   │   │
│                                      │  - private: char grid[3][3] │   │
│                                      │  - makeMove() & undoMove()  │   │
│                                      │  - checkWin() / checkDraw() │   │
│                                      └─────────────────────────────┘   │
│                                                     │                  │
│                      ┌──────────────────────────────┴───────────────┐  │
│                      │   Player (Abstract Base Class - Polymorphism)│  │
│                      │   virtual bool makeMove(int, int) = 0;       │  │
│                      └──────┬───────────────┬───────────────┬───────┘  │
│                             │               │               │          │
│                             ▼               ▼               ▼          │
│                      WebSocketPlayer    LocalPlayer      AIPlayer      │
│                     (Remote WS client) (Console/CLI) (Minimax Tree DFS)│
└────────────────────────────────────────────────────────────────────────┘
```

#### Directory Layout
```
tictactoe_cpp_web/
├── CMakeLists.txt                # Linux CMake build configuration (includes AIPlayer.cpp)
├── Makefile                      # Standard makefile (includes AIPlayer.cpp)
├── build_linux.sh                # Automated build and run script
├── users.txt                     # File-based user database (username:salt:djb2_hash)
├── include/                      # C++ Header Files
│   ├── AuthManager.h             # Authentication and deterministic DJB2 hashing
│   ├── Board.h                   # 3x3 game board encapsulation with undoMove()
│   ├── Player.h                  # Abstract base player
│   ├── AIPlayer.h                # Polymorphic Minimax AI Bot (DSA/DAA Game Tree DFS)
│   ├── WebSocketPlayer.h         # Polymorphic WebSocket player
│   ├── LocalPlayer.h             # Polymorphic local/CLI player
│   ├── GameSession.h             # Turn orchestration and bot match execution
│   └── ServerNetworkManager.h    # Crow WebSocket & REST router
├── src/                          # C++ Implementation Files
│   ├── AuthManager.cpp           # Salted DJB2 implementation
│   ├── Board.cpp                 # Grid mutators, undoMove backtracking & win checks
│   ├── Player.cpp                # Base class constructors & virtual destructor
│   ├── AIPlayer.cpp              # Recursive Minimax algorithm implementation
│   ├── WebSocketPlayer.cpp       # Thread synchronization with condition variables
│   ├── LocalPlayer.cpp           # Stream error-bit recovery
│   ├── GameSession.cpp           # Match state machine & bot trigger
│   ├── ServerNetworkManager.cpp  # Crow routes & WebSocket dispatch
│   └── main.cpp                  # Server entry point with POSIX signal handling
└── public/                       # Frontend Web Client
    └── index.html / client app   # Responsive UI with live gameplay, bot mode & code inspector
```

#### Linux Compilation Commands
```bash
# Compile all translation units including AIPlayer.cpp:
g++ -std=c++17 -Wall -Wextra -O2 -pthread \
    -Iinclude \
    src/AuthManager.cpp \
    src/Board.cpp \
    src/Player.cpp \
    src/AIPlayer.cpp \
    src/WebSocketPlayer.cpp \
    src/LocalPlayer.cpp \
    src/GameSession.cpp \
    src/ServerNetworkManager.cpp \
    src/main.cpp \
    -o tictactoe_server

# Launch the server:
./tictactoe_server 8080
```
